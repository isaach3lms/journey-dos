"""Settings, support, and the audit surface.

Staff only, all of it. Branding changes what every member sees, and the audit
log is a record of who did what, which is not a thing to hand a volunteer.
"""

from __future__ import annotations

import re

from flask import (
    Blueprint,
    abort,
    current_app,
    flash,
    g,
    redirect,
    render_template,
    request,
    url_for,
)
from flask_login import current_user, login_required

from app.accounts import send_set_password
from app.audit import record
from app.brand import assert_accent_readable
from app.content import DOS_PRICE_CENTS, INCLUDED_NOT_SAVED, REPLACES, SETTINGS
from app.extensions import db
from app.mail.health import email_health, explain
from app.models import AuditEvent, BibleVerse, Church, PasswordResetToken, User
from app.models.audit import ROLE_CHANGED
from app.models.password_reset import LIFETIME_MINUTES
from app.models.user import ROLES
from app.models.audit import ACTIONS, BRAND_CHANGED, RETENTION_DAYS
from app.security import min_role
from app.timeutil import COMMON_TIMEZONES, is_valid_timezone

bp = Blueprint("settings", __name__, url_prefix="/settings")


def _cost_context() -> dict:
    replaced = sum(item["cents"] for item in REPLACES)
    return {
        "replaces": REPLACES,
        "included": INCLUDED_NOT_SAVED,
        "replaced_cents": replaced,
        "ours_cents": DOS_PRICE_CENTS,
        "saving_cents": max(0, replaced - DOS_PRICE_CENTS),
    }


@bp.get("/")
@login_required
@min_role("staff")
def index():
    action = (request.args.get("action") or "").strip() or None
    if action and action not in ACTIONS:
        action = None

    return render_template(
        "settings/index.html",
        church=g.church,
        content=SETTINGS,
        timezones=COMMON_TIMEZONES,
        events=db.session.scalars(
            AuditEvent.recent(g.church.id, action=action)
        ).all(),
        actions=ACTIONS,
        active_action=action,
        audit_count=AuditEvent.count_since(g.church.id, 30),
        retention_days=RETENTION_DAYS,
        active="settings",
        users=db.session.scalars(User.for_church(g.church.id)).all(),
        roles=ROLES,
        bible_verses=BibleVerse.verse_count(),
        email=email_health(g.church.id),
        bible_books=len(BibleVerse.loaded_books()),
        **_cost_context(),
    )


@bp.post("/brand/")
@login_required
@min_role("staff")
def save_brand():
    church = g.church
    changes = []

    name = (request.form.get("name") or "").strip()
    if name and name != church.name:
        changes.append(f"name {church.name} to {name}")
        church.name = name[:120]

    # `in request.form` rather than `.get(...) or None`. A field the browser
    # did not send is not the same as a field somebody cleared, and treating
    # them alike wipes a value and records a change nobody made.
    if "app_name" in request.form:
        app_name = request.form["app_name"].strip() or None
        if app_name != church.app_name:
            changes.append("app name")
            church.app_name = app_name

    if "custom_domain" in request.form:
        # This is the field that actually routes. Getting it wrong shows a
        # "no church here" page at that address, so it is validated rather
        # than accepted and left to fail silently.
        host = Church.normalize_host(request.form["custom_domain"])
        if host and not Church.host_looks_valid(host):
            flash(
                SETTINGS["custom_domain_bad"].format(value=request.form["custom_domain"]),
                "error",
            )
            return redirect(url_for("settings.index"))

        if host != (church.custom_domain or ""):
            taken = Church.by_custom_domain(host) if host else None
            if taken is not None and taken.id != church.id:
                flash(SETTINGS["custom_domain_taken"].format(value=host), "error")
                return redirect(url_for("settings.index"))

            changes.append(f"web address to {host or 'none'}")
            church.custom_domain = host or None
            if host:
                flash(SETTINGS["custom_domain_set"].format(value=host), "notice")

    if "app_domain" in request.form:
        app_domain = request.form["app_domain"].strip() or None
        if app_domain != church.app_domain:
            changes.append("app domain")
            church.app_domain = app_domain

    timezone = (request.form.get("timezone") or "").strip()
    if timezone and timezone != church.timezone:
        if not is_valid_timezone(timezone):
            flash(SETTINGS["timezone_rejected"].format(value=timezone), "error")
            return redirect(url_for("settings.index"))
        changes.append(f"timezone to {timezone}")
        church.timezone = timezone

    accent = (request.form.get("accent_hex") or "").strip()
    if accent and accent != church.accent_hex:
        try:
            # The guard written in increment 0, finally wired to a form. A
            # pastor pasting a pale yellow is stopped here rather than
            # discovered by a volunteer squinting at a button in a lobby.
            assert_accent_readable(accent)
        except ValueError as exc:
            flash(SETTINGS["accent_rejected"].format(reason=str(exc)), "error")
            return redirect(url_for("settings.index"))
        changes.append(f"colour to {accent}")
        church.accent_hex = accent

    if changes:
        record(
            BRAND_CHANGED,
            "Branding changed",
            actor=current_user,
            subject_type="church",
            subject_id=church.id,
            subject_label=church.name,
            detail="Changed: " + ", ".join(changes),
        )
    db.session.commit()

    flash(SETTINGS["brand_saved"], "notice")
    return redirect(url_for("settings.index"))


@bp.post("/signup/")
@login_required
@min_role("staff")
def toggle_signup():
    """Open or close self-registration.

    Staff only, and audited, because it changes who can see the church's
    announcements.
    """
    church = g.church
    church.allow_self_signup = not church.allow_self_signup

    record(
        BRAND_CHANGED,
        "Self-registration turned "
        + ("on" if church.allow_self_signup else "off"),
        actor=current_user,
        subject_type="church",
        subject_id=church.id,
        subject_label=church.name,
    )
    db.session.commit()

    flash(
        SETTINGS["signup_changed_on"] if church.allow_self_signup
        else SETTINGS["signup_changed_off"],
        "notice",
    )
    return redirect(url_for("settings.index"))


@bp.post("/announcements/")
@login_required
@min_role("staff")
def toggle_member_announcements():
    """Let members post church-wide announcements, or stop them.

    One switch, audited, so a church can turn it off in a bad week without a
    deploy and turn it back on after.
    """
    church = g.church
    church.members_can_announce = not church.members_can_announce
    record(
        BRAND_CHANGED,
        "Member announcements turned " + ("on" if church.members_can_announce else "off"),
        actor=current_user,
        subject_type="church",
        subject_id=church.id,
        subject_label=church.name,
    )
    db.session.commit()
    flash(
        SETTINGS["announce_changed_on"] if church.members_can_announce
        else SETTINGS["announce_changed_off"],
        "notice",
    )
    return redirect(url_for("settings.index", _anchor="announcements"))


@bp.post("/ccli/")
@login_required
@min_role("staff")
def save_ccli():
    """The church's CCLI license number. Blank removes it."""
    raw = (request.form.get("ccli_license_number") or "").strip()
    digits = re.sub(r"[\s#-]", "", raw)
    if digits and not re.fullmatch(r"\d{4,10}", digits):
        flash(SETTINGS["ccli_bad"], "error")
        return redirect(url_for("settings.index", _anchor="ccli"))

    church = g.church
    church.ccli_license_number = digits or None
    record(
        BRAND_CHANGED,
        f"CCLI license number set to {digits}" if digits else "CCLI license number removed",
        actor=current_user,
        subject_type="church",
        subject_id=church.id,
        subject_label=church.name,
    )
    db.session.commit()
    flash(SETTINGS["ccli_saved"] if digits else SETTINGS["ccli_cleared"], "notice")
    return redirect(url_for("settings.index", _anchor="ccli"))


# ---------------------------------------------------------------------------
# Accounts
#
# Staff only. These decide who can see the roster, the giving, and this page.
# ---------------------------------------------------------------------------

@bp.post("/accounts/")
@login_required
@min_role("staff")
def create_account():
    name = (request.form.get("name") or "").strip()
    email = (request.form.get("email") or "").strip().lower()
    role = (request.form.get("role") or "member").strip()

    if not name or not email:
        flash(SETTINGS["accounts_name_required"], "error")
        return redirect(url_for("settings.index"))
    if role not in ROLES:
        abort(400)

    if User.by_email(g.church.id, email) is not None:
        flash(SETTINGS["accounts_exists"].format(email=email), "error")
        return redirect(url_for("settings.index"))

    user = User(
        church_id=g.church.id, email=email, name=name[:120], role=role
    )
    # A staff member typing an address vouches for it more strongly than a
    # click in an inbox, so the account is verified on creation.
    user.mark_verified()
    user.set_unusable_password()
    db.session.add(user)
    db.session.flush()

    user.link_person_by_email()
    send_set_password(user, current_user)

    record(
        ROLE_CHANGED,
        f"{user.name} was given a {role} account",
        actor=current_user,
        subject_type="user", subject_id=user.id, subject_label=user.name,
    )
    db.session.commit()

    flash(SETTINGS["accounts_created"].format(name=user.name), "notice")
    return redirect(url_for("settings.index"))


@bp.post("/accounts/<int:user_id>/role/")
@login_required
@min_role("staff")
def change_role(user_id: int):
    user = User.get_for_church(g.church.id, user_id)
    if user is None:
        abort(404)

    role = (request.form.get("role") or "").strip()
    if role not in ROLES:
        abort(400)

    if user.id == current_user.id:
        # Changing your own access from this screen is how somebody demotes
        # themselves out of the screen they are standing on.
        flash(SETTINGS["account_self"], "error")
        return redirect(url_for("settings.index"))

    if (
        user.role == "staff"
        and role != "staff"
        and User.active_staff_count(g.church.id, excluding=user.id) == 0
    ):
        flash(SETTINGS["account_last_staff"], "error")
        return redirect(url_for("settings.index"))

    previous, user.role = user.role, role
    record(
        ROLE_CHANGED,
        f"{user.name} changed from {previous} to {role}",
        actor=current_user,
        subject_type="user", subject_id=user.id, subject_label=user.name,
    )
    db.session.commit()

    flash(SETTINGS["role_changed"].format(name=user.name, role=role), "notice")
    return redirect(url_for("settings.index"))


@bp.post("/accounts/<int:user_id>/toggle/")
@login_required
@min_role("staff")
def toggle_account(user_id: int):
    user = User.get_for_church(g.church.id, user_id)
    if user is None:
        abort(404)

    if user.id == current_user.id:
        flash(SETTINGS["account_self"], "error")
        return redirect(url_for("settings.index"))

    if (
        user.is_active_account
        and user.role == "staff"
        and User.active_staff_count(g.church.id, excluding=user.id) == 0
    ):
        flash(SETTINGS["account_last_staff"], "error")
        return redirect(url_for("settings.index"))

    user.is_active_account = not user.is_active_account
    if not user.is_active_account:
        # Switching an account off signs it out everywhere, for the same
        # reason a password reset does.
        user.session_version = (user.session_version or 1) + 1

    record(
        ROLE_CHANGED,
        f"{user.name} was switched "
        + ("back on" if user.is_active_account else "off"),
        actor=current_user,
        subject_type="user", subject_id=user.id, subject_label=user.name,
    )
    db.session.commit()

    flash(
        (SETTINGS["account_reactivated"] if user.is_active_account
         else SETTINGS["account_deactivated"]).format(name=user.name),
        "notice",
    )
    return redirect(url_for("settings.index"))


@bp.post("/accounts/<int:user_id>/resend/")
@login_required
@min_role("staff")
def resend_invite(user_id: int):
    user = User.get_for_church(g.church.id, user_id)
    if user is None:
        abort(404)

    send_set_password(user, current_user)
    db.session.commit()

    flash(SETTINGS["account_resent"].format(email=user.email), "notice")
    return redirect(url_for("settings.index"))


@bp.post("/accounts/<int:user_id>/temp-password/")
@login_required
@min_role("staff")
def temporary_password(user_id: int):
    """Hand somebody a password to use once.

    For a person whose email is dead, or who is standing in front of you. The
    system generates it; staff never choose one, because a password a staff
    member picks becomes a password two people know and is usually one the
    person already uses elsewhere.
    """
    from app.models.audit import PASSWORD_RESET

    user = User.get_for_church(g.church.id, user_id)
    if user is None:
        abort(404)

    if user.id == current_user.id:
        flash(SETTINGS["account_temp_self"], "error")
        return redirect(url_for("settings.index"))

    raw = user.issue_temporary_password()

    # The password itself is deliberately not in the audit entry. The log is
    # designed to be read, kept, and exported; a working password in it is
    # worse than no log.
    record(
        PASSWORD_RESET,
        f"A temporary password was issued for {user.name}",
        actor=current_user,
        subject_type="user", subject_id=user.id, subject_label=user.name,
        detail="They must choose their own before they can use the app.",
    )
    db.session.commit()

    # Shown once, on this screen, and never again.
    flash(
        SETTINGS["account_temp_made"].format(name=user.name, password=raw),
        "notice",
    )
    return redirect(url_for("settings.index"))


@bp.post("/email/test/")
@login_required
@min_role("staff")
def email_test():
    """Send one email to the person pressing the button, right now.

    The answer on screen is the provider's own, so "domain not verified" or
    "invalid API key" shows up here instead of in a log nobody opens. It goes
    through the outbox like everything else, so a test that fails is visible
    in the list below with the same error.
    """
    from app.mail import NotQueued, queue, send_pending
    from app.models import OutboxMessage

    try:
        message = queue(
            church_id=g.church.id,
            category="account",
            subject=SETTINGS["email_test_subject"].format(church=g.church.name),
            body_text=SETTINGS["email_test_body"].format(
                name=current_user.name, church=g.church.name
            ),
            to_email=current_user.email,
            to_name=current_user.name,
            actor=current_user,
        )
    except NotQueued as exc:
        flash(SETTINGS["email_test_not_queued"].format(reason=exc), "error")
        return redirect(url_for("settings.index", _anchor="email"))

    db.session.commit()
    # Sent here rather than after the request, so the result can be shown.
    g.pop("_outbox_ready", None)
    message_id = message.id

    try:
        send_pending(limit=1, message_ids=[message_id])
    except Exception as exc:  # the provider, the network, or the key
        db.session.rollback()
        current_app.logger.exception("Test email failed")
        flash(SETTINGS["email_test_failed"].format(error=str(exc)[:300]), "error")
        return redirect(url_for("settings.index", _anchor="email"))

    sent = db.session.get(OutboxMessage, message_id)
    if sent.status == "sent":
        key = "email_test_sent" if sent.provider_message_id != "console" else "email_test_console"
        flash(SETTINGS[key].format(email=sent.to_email), "notice")
    else:
        why = explain(sent.last_error)
        text = SETTINGS["email_test_failed"].format(error=(sent.last_error or "")[:300])
        if why:
            text += " " + SETTINGS[f"email_why_{why}"]
        flash(text, "error")
    return redirect(url_for("settings.index", _anchor="email"))


RETRY_WINDOW_DAYS = 3


@bp.post("/email/retry/")
@login_required
@min_role("staff")
def email_retry():
    """Put recently failed email back in line and send it now.

    For the morning after a delivery problem is fixed: the people who signed
    up while it was broken should get their link without signing up again.
    Limited to three days, which is how long a confirmation link lasts; older
    mail is stale and resending it would confuse more than it helps.
    """
    from datetime import timedelta

    from app.mail import send_pending
    from app.models import OutboxMessage
    from app.models.base import utcnow

    cutoff = utcnow() - timedelta(days=RETRY_WINDOW_DAYS)
    stuck = db.session.scalars(
        db.select(OutboxMessage).where(
            OutboxMessage.church_id == g.church.id,
            OutboxMessage.status == "failed",
            OutboxMessage.queued_at >= cutoff,
        )
    ).all()
    if not stuck:
        flash(SETTINGS["email_retry_none"], "notice")
        return redirect(url_for("settings.index", _anchor="email"))

    ids = []
    for message in stuck:
        message.status = "queued"
        message.attempts = 0
        message.claim_token = None
        message.claimed_at = None
        ids.append(message.id)
    db.session.commit()

    try:
        counts = send_pending(limit=len(ids), message_ids=ids)
    except Exception:
        db.session.rollback()
        current_app.logger.exception("Retry send failed; left for the worker")
        counts = {"sent": 0, "failed": 0, "retrying": len(ids)}

    flash(
        SETTINGS["email_retry_done"].format(
            total=len(ids),
            sent=counts.get("sent", 0),
            failed=counts.get("failed", 0) + counts.get("retrying", 0),
        ),
        "notice" if counts.get("sent") == len(ids) else "error",
    )
    return redirect(url_for("settings.index", _anchor="email"))
